package it.castelli;
import it.castelli.Eroi.*;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        SuperErori[] eroiPlay = new SuperErori[2];
        SpideMan spide = new SpideMan();
        IronMan iron = new IronMan();
        Venom ven = new Venom();
        BlackPanther black = new BlackPanther();
        CaptainAmerica captain = new CaptainAmerica();
        Thor tho = new Thor();

        CampoIronici campoScelto = new CampoIronici();
        CampoIronici parco = new CampoIronici("Parco", "Campo classico non ha un funzione speciale", 0);
        CampoIronici grattacielo = new CampoIronici("Grattacielo", "Campo classico non ha un funzione speciale", 0);
        CampoIronici campoGravitazione = new CampoIronici("Campo Gravitazione", "Un campo che fa diminuire la velocità di tutti i supereroi", 30);
        CampoIronici cameraGas = new CampoIronici("Camera di gas", "Ogni supereroe diminuisce l'energia ogni turno", 5);


        Random random = new Random();

        int numeroTurno = 0;
        int turnoContinuo1 = 1, turnoContinuo2 = 1;
        boolean toccaAversario1 = false, toccaAversario2 = false;


        for(int j = 0; j < 2 ; j++){
            int n= j+1, scelta;
            System.out.println("Sei play "+ n +" quale dei seguenti eroi vuoi scegliere:");
            System.out.println("1)Spiderman");
            System.out.println("2)Ironman");
            System.out.println("3)Venom");
            System.out.println("4)BlackPanther");
            System.out.println("5)Captain America");
            System.out.println("6)Thor");
            scelta = input.nextInt();
            switch (scelta){
                case 1: eroiPlay[j] = new SuperErori(spide); break;
                case 2: eroiPlay[j] = new SuperErori(iron); break;
                case 3: eroiPlay[j] = new SuperErori(ven); break;
                case 4: eroiPlay[j] = new SuperErori(black); break;
                case 5: eroiPlay[j] = new SuperErori(captain); break;
                case 6: eroiPlay[j] = new SuperErori(tho); break;
                default:
                    System.out.println("Scelta non valida.");
                    j--;
                    break;
            }
        }
        int selezionaCampo = random.nextInt(4);
        switch (selezionaCampo){
            case 0: campoScelto = parco; break;
            case 1: campoScelto = grattacielo; break;
            case 2: campoScelto = campoGravitazione; break;
            case 3: campoScelto = cameraGas; break;
        }
        System.out.println(campoScelto.toString());
        if (campoScelto.getNome().equalsIgnoreCase("Campo Gravitazione")){
            eroiPlay[0].setVelocità(campoScelto.cambiaDati(eroiPlay[0].getVelocità()));
            eroiPlay[1].setVelocità(campoScelto.cambiaDati(eroiPlay[1].getVelocità()));
        }

        TurnoDiGioco(input, eroiPlay, numeroTurno, turnoContinuo1, turnoContinuo2, toccaAversario1, toccaAversario2, campoScelto, random);

        TrovaVincitore(eroiPlay);

    }

    private static void TrovaVincitore(SuperErori[] eroiPlay) {
        if (eroiPlay[0].getEnergia() < 0 && eroiPlay[1].getEnergia() < 0){
            if (eroiPlay[0].getVelocità() > eroiPlay[1].getVelocità()){
                System.out.println("Ha vinto Play 1" + eroiPlay[0].getNome() + "'");
            }
            else {
                System.out.println("Ha vinto Play 2" + eroiPlay[1].getNome() + "'");
            }
        }
        else {
            if (eroiPlay[0].getEnergia() > eroiPlay[1].getEnergia()){
                System.out.println("Ha vinto Play 1 '" + eroiPlay[0].getNome() + "'");
            }
            else {
                System.out.println("Ha vinto Play 2 '" + eroiPlay[1].getNome() + "'");
            }
        }
    }

    private static void TurnoDiGioco(Scanner input, SuperErori[] eroiPlay, int numeroTurno, int turnoContinuo1,
                                     int turnoContinuo2, boolean toccaAversario1, boolean toccaAversario2,
                                     CampoIronici campoScelto, Random random) {
        boolean contF = false;
        boolean contV = false;
        int[] segnaNumero = new int[2];
        int condMov;
        EventiCasuali[] eventiScelto = new EventiCasuali[2];
        EventiCasuali forza = new EventiCasuali("Forza", "Questo evento porta di aumentare la forza in questo turno", 50);
        EventiCasuali energia = new EventiCasuali("Energia", "Questo evento porta di aumentare la energia", 60);
        EventiCasuali velocità = new EventiCasuali("Velocità", "Questo evento porta di aumentare la velocità in questo turno", 5);
        EventiCasuali aumetoNPotereS = new EventiCasuali("Potere unico", "Aumenta un numero di volta del potere specifico", 1);

        do{
            numeroTurno++;
            if (campoScelto.getNome().equalsIgnoreCase("Camera di gas")){
                System.out.println("Avete diminuito 5% di energia per il gas");
                eroiPlay[0].setEnergia(campoScelto.cambiaDati(eroiPlay[0].getEnergia()));
                eroiPlay[1].setEnergia(campoScelto.cambiaDati(eroiPlay[1].getEnergia()));
            }

            System.out.println("\n");
            System.out.println("\nTurno " + numeroTurno + ":");
            for (int cont = 0; cont < 2;cont ++){
                int selezionaEvento = random.nextInt(4);
                switch (selezionaEvento){
                    case 0: eventiScelto[cont] = forza; break;
                    case 1: eventiScelto[cont] = energia; break;
                    case 2: eventiScelto[cont] = velocità; break;
                    case 3: eventiScelto[cont] = aumetoNPotereS; break;
                }
                if (eventiScelto[cont].getNome().equalsIgnoreCase("Forza")){
                    System.out.println(eroiPlay[cont].getNome() + " Evento: aumenta 50% di forza in questo turno.");
                    eroiPlay[cont].setForza(eroiPlay[cont].getForza() + eventiScelto[cont].cambiaDati(eroiPlay[cont].getForza()));
                    segnaNumero[cont] = cont;
                    contF = true;
                }
                else if (eventiScelto[cont].getNome().equalsIgnoreCase("Energia")){
                    System.out.println(eroiPlay[cont].getNome() + " Evento: aumenta 60 di energia.");
                    eroiPlay[cont].setEnergia(eroiPlay[cont].getEnergia() + eventiScelto[cont].getDati());
                }
                else if (eventiScelto[cont].getNome().equalsIgnoreCase("Velocità")){
                    System.out.println(eroiPlay[cont].getNome() + " Evento: aumenta 5 di velocità in questo turno.");
                    eroiPlay[cont].setVelocità(eroiPlay[cont].getVelocità() + eventiScelto[cont].getDati());
                    segnaNumero[cont] = cont;
                    contV = true;
                }
                else if (eventiScelto[cont].getNome().equalsIgnoreCase("Potere unico")){
                    System.out.println(eroiPlay[cont].getNome() + " Evento:  aumenta un numero di volte di utilizzare per utilizzare un potere specifico.");
                    eroiPlay[cont].setVoltaMaxPotereSpecifici(eroiPlay[cont].getVoltaMaxPotereSpecifici() + 1);
                }
            }

            System.out.println(eroiPlay[0].toString());
            System.out.println(eroiPlay[1].toString());

            double contVelocita1 = eroiPlay[0].getVelocità(),
                    contVelocita2 = eroiPlay[1].getVelocità();
            condMov = 0;

            if (contVelocita1>contVelocita2){
                turnoContinuo1 = eroiPlay[0].condizioneVelocita(eroiPlay[1]);
            }
            else{
                turnoContinuo2 = eroiPlay[1].condizioneVelocita(eroiPlay[0]);
            }
            do{
                boolean seRipeti = false;
                if (contVelocita1 > contVelocita2 || toccaAversario1){

                    condMov++;
                    seRipeti = eroiPlay[0].condizioneTurno(input, eroiPlay[1], turnoContinuo1);
                    if (!seRipeti) {
                        toccaAversario1 = false;
                        toccaAversario2 = true;
                    }else {
                        turnoContinuo1--;
                        condMov--;
                    }
                }
                if (contVelocita1 < contVelocita2 || toccaAversario2) {
                    condMov++;
                    seRipeti = eroiPlay[1].condizioneTurno(input, eroiPlay[0], turnoContinuo2);
                    if (!seRipeti) {
                        toccaAversario2 = false;
                        toccaAversario1 = true;
                    }else {
                        turnoContinuo2--;
                        condMov--;
                    }
                }
            }while(condMov < 2);
            for (int i=0;i<2;i++){
                if (eventiScelto[i].getNome().equalsIgnoreCase("Forza")) {
                    eroiPlay[i].setForza(eroiPlay[i].getForza() - eventiScelto[i].cambiaDati(eroiPlay[i].getForza()));
                } else if (eventiScelto[i].getNome().equalsIgnoreCase("Velocità")) {
                    eroiPlay[i].setVelocità(eroiPlay[i].getVelocità() - eventiScelto[i].getDati());
                }
            }
        }while(eroiPlay[0].getEnergia() > 0 && eroiPlay[1].getEnergia() > 0);
    }
}