package it.castelli;

import java.util.Scanner;

public class SuperErori {
    private String nome;
    private int velocità;
    private int energia;
    private int forza;
    private String deBuff = " ";
    private int voltaMaxPotereSpecifici;
    private String nomePotereSpecifici;
    private int  attaccoPotere;
    private String nomeDebuffPotereSpecifici;
    private String spiegazionePotereSpecifici;

    public SuperErori(String nome, int velocità, int energia, int forza, int voltaMaxPotereSpecifici) {
        this.nome = nome;
        this.velocità = velocità;
        this.energia = energia;
        this.forza = forza;
        this.voltaMaxPotereSpecifici = voltaMaxPotereSpecifici;
    }
    public SuperErori(SuperErori e){
        nome = e.getNome();
        velocità = e.getVelocità();
        energia = e.getEnergia();
        forza = e.getForza();
        voltaMaxPotereSpecifici = e.getVoltaMaxPotereSpecifici();
        deBuff = e.getDeBuff();
        nomePotereSpecifici = e.getNomePotereSpecifici();
        attaccoPotere = e.getAttaccoPotere();
        nomeDebuffPotereSpecifici = e.getNomeDebuffPotereSpecifici();
        spiegazionePotereSpecifici = e.getSpiegazionePotereSpecifici();
    }

    public int getVoltaMaxPotereSpecifici() {
        return voltaMaxPotereSpecifici;
    }

    public String getDeBuff() {
        return deBuff;
    }

    public void setDeBuff(String deBuff) {
        this.deBuff = deBuff;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getEnergia() {
        return energia;
    }

    public void setEnergia(int energia) {
        this.energia = energia;
    }

    public int getForza() {
        return forza;
    }

    public void setForza(int forza) {
        this.forza = forza;
    }

    public int getVelocità() {
        return velocità;
    }

    public void setVelocità(int velocità) {
        this.velocità = velocità;
    }

    public void setVoltaMaxPotereSpecifici(int voltaMaxPotereSpecifici) {
        this.voltaMaxPotereSpecifici = voltaMaxPotereSpecifici;
    }

    public String getNomePotereSpecifici() {
        return nomePotereSpecifici;
    }

    public void setNomePotereSpecifici(String nomePotereSpecifici) {
        this.nomePotereSpecifici = nomePotereSpecifici;
    }

    public int getAttaccoPotere() {
        return attaccoPotere;
    }

    public void setAttaccoPotere(int attaccoPotere) {
        this.attaccoPotere = attaccoPotere;
    }

    public String getNomeDebuffPotereSpecifici() {
        return nomeDebuffPotereSpecifici;
    }

    public void setNomeDebuffPotereSpecifici(String nomeDebuffPotereSpecifici) {
        this.nomeDebuffPotereSpecifici = nomeDebuffPotereSpecifici;
    }

    public String getSpiegazionePotereSpecifici() {
        return spiegazionePotereSpecifici;
    }

    public void setSpiegazionePotereSpecifici(String spiegazionePotereSpecifici) {
        this.spiegazionePotereSpecifici = spiegazionePotereSpecifici;
    }

    public boolean verPS(){
        if (getVoltaMaxPotereSpecifici()>0){
            setVoltaMaxPotereSpecifici(getVoltaMaxPotereSpecifici()-1);
            return true;
        }
        else{
            System.out.println("Hai finito le possibilità di usare il potere specifico.");
            return false;
        }
    }

    public int usoPotereSpecifici(SuperErori aversario){
        if(verPS()){
            if (nomeDebuffPotereSpecifici.equals("Bruciato")){
                aversario.setForza(aversario.getForza()-(aversario.getForza()/100*10));
            }
            if (nomeDebuffPotereSpecifici.equals("Ragnatela cavalcata")){
                aversario.setVelocità(aversario.getVelocità()-2);
            }
            if (nomeDebuffPotereSpecifici.equals("Ragnatela organica")){
                aversario.setVelocità(aversario.getVelocità()-1);
                aversario.setForza(aversario.getForza()-(aversario.getForza()/100*5));
            }
            if(nomeDebuffPotereSpecifici.equals("Sanguinamento")){
                aversario.setEnergia(aversario.getEnergia()-(aversario.getEnergia()/100*20));
            }
            if (nomeDebuffPotereSpecifici.equals("Elettrificazione")){
                aversario.setVelocità(aversario.getVelocità()-3);
            }
            return getAttaccoPotere();
        }
        else
            return 0;
    }

    public boolean condizioneTurno(Scanner input, SuperErori playDiffesa, int turnoContinuo){
        boolean seRipeti = false;
        int informazioniDanniTolti=0;
        turnoContinuo--;
        System.out.println("\nTocca '" + nome + "' cosa vuoi fare: ");
        System.out.println("1)Attacco normale;");
        System.out.println("2)Uso potere specifico;");
        System.out.println("3)Difesa(aumenta 70 di energia);");
        int sceltaATurno = input.nextInt();
        switch (sceltaATurno){
            case 1:
                informazioniDanniTolti = forza;
                System.out.println("Hai tolto " + informazioniDanniTolti + " di energia aversaria.");
                playDiffesa.setEnergia(playDiffesa.getEnergia()-informazioniDanniTolti);
                break;
            case 2:
                if (voltaMaxPotereSpecifici!=0) {
                    informazioniDanniTolti = usoPotereSpecifici(playDiffesa);
                    System.out.println("Hai tolto " + informazioniDanniTolti + " di energia aversaria.");
                    System.out.println("Hai aggiunto debuff: " + nomeDebuffPotereSpecifici);
                    playDiffesa.setEnergia(playDiffesa.getEnergia() - informazioniDanniTolti);
                    playDiffesa.setDeBuff(nomeDebuffPotereSpecifici);
                }else{
                    System.out.println("Hai finito la possibilita di  utilizzare il potere speifico.");
                    seRipeti = true;
                    turnoContinuo++;
                }
                break;
            case 3:
                System.out.println("Hai aumentato 70 di energia.");
                energia += 70;
                break;
            default:
                break;
        }
        if (turnoContinuo > 0 && !seRipeti){
            seRipeti = true;
        }
        return seRipeti;
    }

    public int condizioneVelocita(SuperErori eroiAverssario){
        double cont = velocità;
        int contatore = 0;
        do{
            cont -= eroiAverssario.getVelocità();
            if (cont>0){
                contatore++;
            }
        }while (cont>0);
        return contatore;
    }

    @Override
    public String toString() {
        return "SuperErori: " + "\n" +
                "-Nome: " + nome + "\n" +
                "-Velocità: " + velocità + "\n" +
                "-Energia: " + energia + "\n" +
                "-Forza: " + forza + "\n" +
                "-DeBuff: " + deBuff + "\n" +
                "-Nome del potere specifico: " + getNomePotereSpecifici() + "\n" +
                "-Numero di volte per potere unico: " + getVoltaMaxPotereSpecifici() + "\n" +
                "-Attacco del potere specifico: " + getAttaccoPotere() + "\n" +
                "-Nome del debuff del potere specifico: " + getNomeDebuffPotereSpecifici() + "\n" +
                "-Spiegazione dei poteri specifici: " + getSpiegazionePotereSpecifici() + "\n";
    }
}
