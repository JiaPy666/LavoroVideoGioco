package it.castelli.Eroi;

import it.castelli.SuperErori;

public class BlackPanther extends SuperErori {
    public BlackPanther() {
        super("BlackPanther", 5, 800, 90, 1);
        setNomePotereSpecifici("Armi avanzate");
        setAttaccoPotere(100);
        setNomeDebuffPotereSpecifici("Sanguinamento");
        setSpiegazionePotereSpecifici("Perde la vita 20%");
    }
    
}
