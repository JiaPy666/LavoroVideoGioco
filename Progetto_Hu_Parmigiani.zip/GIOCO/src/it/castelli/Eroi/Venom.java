package it.castelli.Eroi;

import it.castelli.SuperErori;

public class Venom extends SuperErori {
    public Venom() {
        super("Venom", 7, 700, 150, 1);
        setNomePotereSpecifici("Ragnatele organica");
        setAttaccoPotere(100);
        setNomeDebuffPotereSpecifici("Avelenato");
        setSpiegazionePotereSpecifici("Diminuisce la velocità di 1 e forza di 5%");
    }
}
