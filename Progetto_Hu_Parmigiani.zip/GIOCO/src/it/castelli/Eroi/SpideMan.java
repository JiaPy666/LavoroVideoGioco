package it.castelli.Eroi;

import it.castelli.SuperErori;

public class SpideMan extends SuperErori {
    public SpideMan() {
        super("SpiderMan", 9, 600, 100, 2);
        setNomePotereSpecifici("Spara rete");
        setAttaccoPotere(100);
        setNomeDebuffPotereSpecifici("Ragnatela cavalcata");
        setSpiegazionePotereSpecifici("Diminuisce la velocità di 2");
    }
}
