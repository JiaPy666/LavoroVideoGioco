package it.castelli.Eroi;

import it.castelli.SuperErori;

public class IronMan extends SuperErori {
    public IronMan() {
        super("IronMan", 6, 800, 100, 1);
        setNomePotereSpecifici("Cannone laser");
        setAttaccoPotere(100);
        setNomeDebuffPotereSpecifici("Bruciato");
        setSpiegazionePotereSpecifici("Diminuisce la attacco di 10%");
    }

}
