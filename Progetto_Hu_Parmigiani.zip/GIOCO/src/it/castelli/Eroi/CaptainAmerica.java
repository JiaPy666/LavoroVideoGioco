package it.castelli.Eroi;

import it.castelli.SuperErori;

public class CaptainAmerica extends SuperErori {
    public CaptainAmerica() {
        super("Captain American", 8, 800, 120, 1);
        setNomePotereSpecifici("Scudo");
        setAttaccoPotere(200);
        setNomeDebuffPotereSpecifici(" ");
        setSpiegazionePotereSpecifici(" ");
    }
}
