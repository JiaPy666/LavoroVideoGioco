package it.castelli.Eroi;

import it.castelli.SuperErori;

public class Thor extends SuperErori {
    public Thor() {
        super("Thor", 6, 600, 130, 1);
        setNomePotereSpecifici("Fulmini");
        setAttaccoPotere(100);
        setNomeDebuffPotereSpecifici("Elettrificazione");
        setSpiegazionePotereSpecifici("Diminuisce la velocità di 3");
    }
}
