package it.castelli;

public class CampoIronici {
    private String nome;
    private String descrizione;
    private int dati;

    public CampoIronici(String nome, String descrizione, int dati) {
        this.nome = nome;
        this.descrizione = descrizione;
        this.dati = dati;
    }

    public CampoIronici(){
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public int getDati() {
        return dati;
    }

    public void setDati(int dati) {
        this.dati = dati;
    }

    public int  cambiaDati(int d){
        return d-(d/100*dati);
    }

    @Override
    public String toString() {
        return "Campo: " + "\n" +
                "-Nome: " + nome + "\n" +
                "-Descrizione: " + descrizione;
    }
}
